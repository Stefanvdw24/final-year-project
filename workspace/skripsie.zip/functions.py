import numpy as np
import pylab as pl
from numpy.linalg import inv

def heatmap_random(data,n):
    #
    
    w0 = np.zeros(n)
    w1 = np.zeros(n)
    
    for a in range(0,n):
        data_raveled = data.ravel()
        data_sum = np.sum(data_raveled)
        q = 0
        o = np.random.uniform(0,1) * data_sum
        e = 0
        i=1
        while e==0:
            q += data_raveled[i]
            if (q > o):
                e = i
                break
            i+=1
        w1[a] = -1 + (e/100 - (e%100)/100)*0.02
        w0[a] = -1 + (e%100)*0.02
    return w0, w1

def basis(x,mu,s):
    #the function for evaluating a basis function given a point in N-dimensional input space and also a mean and a variance.
    D = np.shape(mu)[0]
    magnitude = 0
    for a in range(0,D):
        magnitude += (x[a] - mu[a])**2
    magnitude = np.sqrt(magnitude)
    phi = np.exp(-(magnitude**2)/(2*(s**2)))
    return phi

def com_gauss_proc_kern(x_n, x_m, theta0, theta1, theta2, theta3):
    #the name is a shortened form of "common Gaussian process kernel".
    #This function calculates equation 6.63 for given parameters and 2 given x vectors.
    #Note: x_n and x_m has to be arrays. It has to be defined with functions like "np.array" or
    #"np.atleast_2d". Declarations like "x = 1" or "x = [3,3]" will not work.
    #The theta arguments are single values
    x_n = x_n.ravel()
    x_m = x_m.ravel()
    term1 = theta0*np.exp( (-theta1/2)*((np.sqrt( ((np.subtract(x_m,x_n))**2).sum()  ))**2)  )
    result = term1 + theta2 + theta3*np.sum(x_n*x_m)
    return result

def gauss_proc_kern_reg_cov(x_train, x_test, theta0, theta1, theta2, theta3, beta):
    #the name is a shortened form of "Gaussian process kernel regression covariance"
    #x_train is a an (n, d) array, where d is the number of dimensions and n is the number of training points.
    #if x_train is one-dimensional, use np.atleast_2d on it before passing it ti this definition
    #returns: cov_N, k, k_T, c, cov_full, inv_cov_N
    n, d = np.shape(x_train)
    x_full = np.append(x_train,np.atleast_2d(x_test)).reshape(n+1,d)
    cov = np.zeros([n+1,n+1])
    for a in range(0,n+1):
        for b in range(0,n+1):
            cov[a,b] = com_gauss_proc_kern(x_full[a,:], x_full[b,:], theta0, theta1, theta2, theta3 )
            if (a==b):
                cov[a,b] += (1/beta)
    inv_cov_N = inv(cov[:n,:n])
    return cov[:n,:n], cov[:n,n], cov[n,:n], cov[n,n], cov, inv_cov_N

def gauss_proc_kern_reg_pred_mean(k_T,C_N,t, inv_cov_N):
    #the name is a shortened form of "Gaussian process kernel regression prediction mean"
    o = np.dot(k_T,inv_cov_N)
    i = np.dot(np.atleast_2d(o),np.atleast_2d(t.ravel()).transpose() )
    return i

def gauss_proc_kern_reg_pred_var(c,k_T,C_N,k, inv_cov_N):
    #the name is a shortened form of "Gaussian process kernel regression prediction variance"
    o = np.dot(k_T,inv_cov_N)
    i = c - np.dot(np.atleast_2d(o),k )
    return i 

def theta0_deriv(x_n, x_m, theta0, theta1):
    x_n = x_n.ravel()
    x_m = x_m.ravel()
    result = np.exp( (-theta1/2)*((np.sqrt( ((np.subtract(x_m,x_n))**2).sum()  ))**2)  )
    return result
def theta1_deriv(x_n, x_m, theta0, theta1):
    x_n = x_n.ravel()
    x_m = x_m.ravel()
    result1 = theta0*np.exp( (-theta1/2)*((np.sqrt( ((np.subtract(x_m,x_n))**2).sum()  ))**2)  )
    result = result1*(-1/2)*((np.sqrt( ((np.subtract(x_m,x_n))**2).sum()  ))**2)
    return result
def theta3_deriv(x_n, x_m, theta3):
    x_n = x_n.ravel()
    x_m = x_m.ravel()
    result = np.sum(x_n*x_m)
    return result

def gauss_proc_kern_reg_deriv_values(x_train, theta0, theta1, theta2, theta3, beta):
    #the name is a shortened form of "Gaussian process kernel regression derivative values"
    #It returns all the values needed to solve equation (6.70)
    #x_train is a an (n, d) array, where d is the number of dimensions and n is the number of training points.
    #if x_train is one-dimensional, use np.atleast_2d on it before passing it ti this definition
    #returns: cov_N, k, k_T, c, cov_full
    n, d = np.shape(x_train)
    cov = np.zeros([n,n])
    cov_theta0_deriv = np.zeros([n,n])
    cov_theta1_deriv = np.zeros([n,n])
    cov_theta2_deriv = np.zeros([n,n])
    cov_theta3_deriv = np.zeros([n,n])
    for a in range(0,n):
        for b in range(0,n):
            cov[a,b] = com_gauss_proc_kern(x_train[a,:], x_train[b,:], theta0, theta1, theta2, theta3 )
            cov_theta0_deriv[a,b] = theta0_deriv(x_train[a,:], x_train[b,:], theta0, theta1 )
            cov_theta1_deriv[a,b] = theta1_deriv(x_train[a,:], x_train[b,:], theta0, theta1 )
            cov_theta2_deriv[a,b] = 1
            cov_theta3_deriv[a,b] = theta3_deriv(x_train[a,:], x_train[b,:], theta3 )
            if (a==b):
                cov[a,b] += (1/beta)
    inv_cov = inv(cov) #inverse of the matrix covariance
    return cov, inv_cov, cov_theta0_deriv, cov_theta1_deriv, cov_theta2_deriv, cov_theta3_deriv

def gauss_proc_kern_reg_deriv(x_train, t_train, inv_cov, cov_theta_deriv):
    term1 = (-1/2)*np.trace(np.dot(inv_cov,cov_theta_deriv))
    term2 = np.dot(t_train.transpose(),inv_cov)
    term2 = np.dot(term2,cov_theta_deriv)
    term2 = np.dot(term2,inv_cov)
    term2 = (-1/2)*np.dot(term2,t_train)
    result = term1 + term2
    return result













